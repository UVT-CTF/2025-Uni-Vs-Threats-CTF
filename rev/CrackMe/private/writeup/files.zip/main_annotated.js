/* https://obf-io.deobfuscate.io/ */

function programState(_0x4cc628) {
    this.data = new DataView(_0x4cc628);
    this.bytelen = this.data.byteLength;
    this.offset = 0;
    this.someInteger = 23;
  }
  programState.prototype.EOF = function () {
    return this.offset >= this.data.byteLength;
  };
  programState.prototype.nextUInt8 = function () {
    if (this.bytelen - this.offset < 1) {
      return;
    }
    let byt = this.data.getUint8(this.offset);
    this.offset++;
    return byt;
  };
  programState.prototype.nextUInt16 = function () {
    if (this.bytelen - this.offset < 2) {
      return;
    }
    let _0xfc9d22 = this.data.getUint16(this.offset, false);
    this.offset += 2;
    return _0xfc9d22;
  };
  programState.prototype.nextFloat32 = function () {
    if (this.bytelen - this.offset < 4) {
      return;
    }
    let _0x381c19 = this.data.getFloat32(this.offset, false);
    this.offset += 4;
    return _0x381c19;
  };
  programState.prototype.nextInt16 = function () {
    if (this.bytelen - this.offset < 2) {
      return;
    }
    let _0x1e13c0 = this.data.getInt16(this.offset, false);
    this.offset += 2;
    return _0x1e13c0;
  };
  programState.prototype.nextUInt32 = function () {
    if (this.bytelen - this.offset < 4) {
      return;
    }
    let _0x1cf300 = this.data.getUint32(this.offset, false);
    this.offset += 4;
    return _0x1cf300;
  };
  programState.prototype.nextInt32 = function () {
    if (this.bytelen - this.offset < 4) {
      return;
    }
    let _0x519dd9 = this.data.getInt32(this.offset, false);
    this.offset += 4;
    return _0x519dd9;
  };
  programState.prototype.toStringWithExtraSteps = function () {
    let str = '';
    let _0x28d788 = this.nextUInt16() ^ 15821;
    let acc = 0;
    for (let _0x1b5bc6 = 0; _0x1b5bc6 < _0x28d788; _0x1b5bc6++) {
      let _0x1801d5 = this.nextInt16() ^ this.someInteger;
      str += String.fromCharCode(_0x1801d5 + acc);
      this.someInteger ^= 25;
      acc = _0x1801d5 + acc;
    }
    return str;
  };
  programState.prototype.getNextDataUntillAlignTo = function (_0x52301b) {
    while (this.offset % _0x52301b !== 0) {
      this.nextUInt8();
    }
  };
  function check1(data, inputData = []) {
    let resultSet = {};
    let _0xf7dd84 = 0;
    let var1 = 0;
    let var2 = 0;

    for (let _0x46418a of inputData) resultSet[++_0xf7dd84] = _0x46418a;
    
    let PS = new programState(data);

    function nextIntOrFloat() {
      let _0x3794e4 = PS.nextUInt8();
      switch (_0x3794e4) {
        case 1:
          return PS.nextInt32();
        case 2:
          return PS.nextFloat32();
      }
    }

    const _0x21dbf7 = PS.nextUInt16();
    PS.getNextDataUntillAlignTo(8);
    if (_0x21dbf7 > 180) {
      throw new Error("error");
    }

    /* the operations performed do not depend on the input data so we can just log the operations done and see what happens */
    /* the return 0 mechanism seems to be to set offset to 1136 */
    while (!PS.EOF()) {
      let whatDO = PS.nextUInt8() ^ 174;
      let intermOffset;
      switch (whatDO) {
        case 1:
          intermOffset = PS.nextUInt16();
          var1 = nextIntOrFloat();
          resultSet[intermOffset] = var1
          console.log(`1\tresultSet[${intermOffset}] = ${var1};`)
          break;
        case 2:
          intermOffset = PS.nextUInt16();
          var1 = nextIntOrFloat();
          resultSet[intermOffset] += var1;
          console.log(`2\tresultSet[${intermOffset}] += ${var1}; = ${resultSet[intermOffset]}`)
          break;
        case 3:
          intermOffset = PS.nextUInt16();
          var1 = nextIntOrFloat();
          resultSet[intermOffset] ^= resultSet[intermOffset] >>> var1;
          console.log(`3\tresultSet[${intermOffset}] ^= resultSet[${intermOffset}](${resultSet[intermOffset]}) >>> ${var1}; = ${resultSet[intermOffset]}`)
          break;
        case 4:
          intermOffset = PS.nextUInt16();
          var1 = nextIntOrFloat();
          resultSet[intermOffset] = Math.imul(resultSet[intermOffset], var1);
          console.log(`4\tresultSet[${intermOffset}] = Math.imul(resultSet[${intermOffset}](${resultSet[intermOffset]}), ${var1}); = ${resultSet[intermOffset]}`)
          break;
        case 5:
          intermOffset = PS.nextUInt16();
          if (resultSet[intermOffset] < 0) {
            resultSet[intermOffset] = -resultSet[intermOffset];
            console.log(`5\tresultSet[${intermOffset}] < 0; resultSet[${intermOffset}] = -resultSet[${intermOffset}](${resultSet[intermOffset]}) = ${resultSet[intermOffset]}`);
          }else{
            console.log(`5\tresultSet[${intermOffset}] >= 0`);
          }
          break;
        case 6:
          intermOffset = PS.nextUInt16();
          let _0x46734e = resultSet[PS.nextUInt16()];
          resultSet[intermOffset] = undefined;
          let _0x379806 = PS.nextUInt8();
          for (let _0x5c5420 = 0; _0x5c5420 < _0x379806; _0x5c5420++) {
            let strex = PS.toStringWithExtraSteps();
            resultSet[intermOffset] = (resultSet[intermOffset] || _0x46734e)[strex];
            console.log(`6\tresultSet[${intermOffset}] = ${resultSet[intermOffset] || _0x46734e}[${strex}] = ${resultSet[intermOffset]}`);
          }
          break;
        case 7:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          var2 = PS.nextUInt16();
          resultSet[intermOffset] = resultSet[var1] > resultSet[var2];
          console.log(`7\tresultSet[${intermOffset}] = ${resultSet[var1]}(resultSet[${var1}]) > ${resultSet[var2]}(resultSet[${var2}]) = ${resultSet[intermOffset]}`);
          break;
        case 8:
          //   intermOffset = PS.nextUInt16();
          //   resultSet[intermOffset] = resultSet[PS.nextUInt16()] === resultSet[PS.nextUInt16()];
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          var2 = PS.nextUInt16();
          resultSet[intermOffset] = resultSet[var1] === resultSet[var2];
          console.log(`\t\tchecking equals to ${resultSet[var2]}`);
          console.log(`8\tresultSet[${intermOffset}] = ${resultSet[var1]}(resultSet[${var1}]) === ${resultSet[var2]}(resultSet[${var2}]) = ${resultSet[intermOffset]}`);
          break;
        case 9:
          //   intermOffset = PS.nextUInt16();
          //   resultSet[intermOffset] = resultSet[PS.nextUInt16()] >= resultSet[PS.nextUInt16()];
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          var2 = PS.nextUInt16();
          resultSet[intermOffset] = resultSet[var1] >= resultSet[var2];
          console.log(`9\tresultSet[${intermOffset}] = ${resultSet[var1]}(resultSet[${var1}]) >= ${resultSet[var2]}(resultSet[${var2}]) = ${resultSet[intermOffset]}`);
          break;
        case 10:
          intermOffset = PS.nextUInt16();
          /* we are patching the fail check */
          // if (!resultSet[intermOffset]) {
          //   var1 = PS.nextUInt32();
          //   PS.offset = var1
          //   console.log(`10\t${!resultSet[intermOffset]}(!resultSet[${intermOffset}]); setting PS.offset to ${var1}`);
          // }else{
          //   console.log(`10\t${!resultSet[intermOffset]}(!resultSet[${intermOffset}])`);
          // }
          break;
        case 11:
          intermOffset = PS.nextUInt16();
          if (resultSet[intermOffset]) {
            var1 = PS.nextUInt32();
            PS.offset = var1
            console.log(`11\t${resultSet[intermOffset]}(!resultSet[${intermOffset}]); setting PS.offset to ${var1}`);
          }else{
            console.log(`11\t${resultSet[intermOffset]}(!resultSet[${intermOffset}])`);
          }
          break;
        case 12:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset] = resultSet[var1];
          console.log(`12\tresultSet[${intermOffset}] = resultSet[${var1}];`)

          break;
        case 13:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset] %= resultSet[var1];
          console.log(`13\tresultSet[${intermOffset}] %= resultSet[${var1}]; = ${resultSet[intermOffset]}`);
          break;
        case 14:
          var1 = PS.nextUInt16()
          var2 = PS.nextUInt16()
          var3 = PS.nextUInt16()
          let a = resultSet[var1];
          let b = resultSet[var2];
          let c = resultSet[var3];
          let ab = a[b];
          a[b] = a[c];
          a[c] = ab;
          console.log(`14\tswapping vals a[${b}], a[${c}] where a = resultSet[${var1}](${a}); b = resultSet[${var2}](${b}); c = resultSet[${var3}](${c})`);
          break;
        case 15:
          // should return 1 when correct pw
          var1 = PS.nextUInt16();
          console.log(`15\treturning resultSet[${var1}](${resultSet[var1]})`);

          console.log("\n\n");
          console.log(resultSet);
          console.log("\n\n");

          return resultSet[var1];
        case 16:
          let _0x26ecba = PS.nextUInt8();
          let _0x1630d0 = '';
          for (let _0x25a81e = 0; _0x25a81e < _0x26ecba; _0x25a81e++) {
            _0x1630d0 += resultSet[PS.nextUInt16()] + " ";
          }
          console.log(_0x1630d0);
          break;
        case 18:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset] += resultSet[var1];
          console.log(`18\tresultSet[${intermOffset}] += ${resultSet[var1]}; = ${resultSet[intermOffset]}`)
          break;
        case 20:
          intermOffset = PS.nextUInt16();
          resultSet[intermOffset] = [];
          console.log(`20\tresultSet[${intermOffset}] = [];`)
          break;
        case 21:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset].push(resultSet[var1]);
          console.log(`21\tresultSet[${intermOffset}].push(${resultSet[var1]}); = ${resultSet[intermOffset]}`)
          break;
        case 22:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          var2 = PS.nextUInt16();
          resultSet[intermOffset] = resultSet[var1][resultSet[var2]];
          console.log(`22\tresultSet[${intermOffset}] = resultSet[${var1}][resultSet[${var2}](${resultSet[var2]})]; = ${resultSet[intermOffset]}`);
          break;
        case 23:
          intermOffset = PS.nextUInt16();
          resultSet[intermOffset] = !resultSet[intermOffset];
          console.log(`23\tresultSet[${intermOffset}] = !${resultSet[intermOffset]}; (toggle)`);
          break;
        case 24:
          intermOffset = PS.nextUInt16();
          var1 = PS.toStringWithExtraSteps();
          resultSet[intermOffset] = var1;
          console.log(`24\tresultSet[${intermOffset}] = ${var1};`)
          break;
        case 25:
          intermOffset = PS.nextUInt16();
          let _0x206b40 = PS.nextUInt8();
          let _0x342f22 = [];
          for (let _0x4182c2 = 0; _0x4182c2 < _0x206b40; _0x4182c2++) {
            var1 = PS.nextUInt16();
            _0x342f22.push(resultSet[var1]);
          }
          resultSet[intermOffset].apply(null, _0x342f22);
          console.log(`25\tresultSet[${intermOffset}].apply(null, ${_0x342f22}) = ${resultSet[intermOffset]}`)
          break;
        case 26:
          intermOffset = PS.nextUInt16();
          let _0x62862b = PS.nextUInt16();
          let _0x23b255 = PS.nextUInt8();
          let _0x1a8025 = [];
          for (let _0x5dc900 = 0; _0x5dc900 < _0x23b255; _0x5dc900++) {
            _0x1a8025.push(resultSet[PS.nextUInt16()]);
          }
          resultSet[_0x62862b] = resultSet[intermOffset].apply(null, _0x1a8025);
          console.log(`26\tresultSet[${_0x62862b}] = resultSet[${intermOffset}].apply(null, ${_0x1a8025}); = ${resultSet[_0x62862b]}`)
          break;
        case 27:
          intermOffset = PS.nextUInt16();
          let _0xc984b = PS.toStringWithExtraSteps();
          let _0x49bf35 = resultSet[intermOffset];
          let _0x87a966 = PS.nextUInt16();
          let _0x10fe4f = PS.nextUInt8();
          let _0xa9b33 = [];
          for (let _0x148e21 = 0; _0x148e21 < _0x10fe4f; _0x148e21++) {
            _0xa9b33.push(resultSet[PS.nextUInt16()]);
          }
          resultSet[_0x87a966] = _0x49bf35[_0xc984b].apply(_0x49bf35, _0xa9b33);
          console.log(`27\tresultSet[${_0x87a966}] = ${_0x49bf35[_0xc984b]}.apply(${_0x49bf35}, ${_0xa9b33}); = ${resultSet[_0x87a966]}`)
          break;
        case 28:
          intermOffset = PS.nextUInt16();
          var1 = PS.toStringWithExtraSteps();
          var2 = PS.nextUInt16();
          resultSet[intermOffset][var1] = resultSet[var2];
          console.log(`28\tresultSet[${intermOffset}][${var1}] = resultSet[${var2}]; = ${resultSet[var2]}`);
          break;
        case 29:
          intermOffset = PS.nextUInt16();
          var1 = nextIntOrFloat();
          resultSet[intermOffset] &= var1
          console.log(`29\tresultSet[${intermOffset}] &= ${var1} = ${resultSet[intermOffset]}`)
          break;
        case 30:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset] ^= resultSet[var1];
          console.log(`30\tresultSet[${intermOffset}] ^= resultSet[${var1}](${resultSet[var1]}) = ${resultSet[intermOffset]}`)
          break;
        case 31:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          resultSet[intermOffset] >>>= resultSet[var1];
          console.log(`31\tresultSet[${intermOffset}] >>>= resultSet[${var1}](${resultSet[var1]}) = ${resultSet[intermOffset]}`)
          break;
        case 32:
          intermOffset = PS.nextUInt16();
          var1 = PS.nextUInt16();
          var2 = PS.nextUInt16();
          resultSet[intermOffset][resultSet[var1]] = resultSet[var2];
          console.log(`32\tresultSet[${intermOffset}][resultSet[${var1}](${resultSet[var1]})] = resultSet[${var2}]${resultSet[var2]};`)
          break;
        default:
          throw new Error("invalid: " + whatDO + " " + PS.offset);
      }
      PS.getNextDataUntillAlignTo(8);
    }
  }
  const data = new Uint8Array([0, 180, 156, 99, 83, 131, 19, 230, 175, 6, 150, 1, 222, 173, 190, 239, 175, 6, 149, 1, 0, 0, 0, 0, 168, 6, 148, 0, 1, 1, 61, 203, 0, 123, 255, 247, 0, 30, 255, 247, 0, 26, 255, 250, 166, 135, 228, 109, 172, 6, 148, 1, 255, 255, 255, 255, 162, 6, 155, 6, 148, 93, 9, 179, 172, 6, 155, 1, 0, 0, 0, 1, 172, 6, 150, 1, 158, 55, 121, 185, 173, 6, 150, 1, 0, 0, 0, 16, 170, 6, 150, 1, 33, 240, 170, 173, 173, 6, 150, 1, 0, 0, 0, 15, 170, 6, 150, 1, 115, 90, 45, 151, 173, 6, 150, 1, 0, 0, 0, 15, 162, 6, 154, 6, 150, 131, 42, 134, 163, 6, 154, 6, 155, 78, 52, 59, 171, 6, 154, 219, 87, 102, 68, 194, 160, 0, 1, 6, 154, 6, 148, 226, 172, 6, 150, 1, 158, 55, 121, 185, 173, 6, 150, 1, 0, 0, 0, 16, 170, 6, 150, 1, 33, 240, 170, 173, 173, 6, 150, 1, 0, 0, 0, 15, 170, 6, 150, 1, 115, 90, 45, 151, 173, 6, 150, 1, 0, 0, 0, 15, 184, 6, 153, 0, 1, 6, 148, 212, 162, 6, 152, 6, 150, 60, 134, 81, 175, 6, 159, 1, 0, 0, 0, 2, 177, 6, 152, 6, 159, 131, 126, 237, 176, 6, 153, 6, 152, 164, 25, 79, 179, 6, 153, 1, 0, 0, 0, 255, 142, 0, 1, 6, 148, 6, 153, 73, 172, 6, 148, 1, 255, 255, 255, 255, 169, 6, 158, 6, 148, 6, 149, 145, 165, 6, 158, 0, 0, 0, 56, 148, 175, 6, 157, 1, 0, 0, 0, 48, 175, 6, 156, 1, 0, 0, 0, 0, 184, 6, 163, 0, 1, 6, 156, 70, 166, 6, 158, 6, 163, 6, 157, 228, 164, 6, 158, 0, 0, 4, 112, 22, 175, 6, 157, 1, 0, 0, 0, 32, 175, 6, 156, 1, 0, 0, 0, 1, 184, 6, 163, 0, 1, 6, 156, 230, 166, 6, 158, 6, 163, 6, 157, 172, 164, 6, 158, 0, 0, 4, 112, 208, 175, 6, 157, 1, 0, 0, 0, 83, 175, 6, 156, 1, 0, 0, 0, 2, 184, 6, 163, 0, 1, 6, 156, 39, 166, 6, 158, 6, 163, 6, 157, 203, 164, 6, 158, 0, 0, 4, 112, 191, 175, 6, 157, 1, 0, 0, 0, 245, 175, 6, 156, 1, 0, 0, 0, 3, 184, 6, 163, 0, 1, 6, 156, 219, 166, 6, 158, 6, 163, 6, 157, 77, 164, 6, 158, 0, 0, 4, 112, 215, 175, 6, 157, 1, 0, 0, 0, 235, 175, 6, 156, 1, 0, 0, 0, 4, 184, 6, 163, 0, 1, 6, 156, 225, 166, 6, 158, 6, 163, 6, 157, 0, 164, 6, 158, 0, 0, 4, 112, 243, 175, 6, 157, 1, 0, 0, 0, 124, 175, 6, 156, 1, 0, 0, 0, 5, 184, 6, 163, 0, 1, 6, 156, 231, 166, 6, 158, 6, 163, 6, 157, 52, 164, 6, 158, 0, 0, 4, 112, 61, 175, 6, 157, 1, 0, 0, 0, 151, 175, 6, 156, 1, 0, 0, 0, 6, 184, 6, 163, 0, 1, 6, 156, 132, 166, 6, 158, 6, 163, 6, 157, 203, 164, 6, 158, 0, 0, 4, 112, 31, 175, 6, 157, 1, 0, 0, 0, 6, 175, 6, 156, 1, 0, 0, 0, 7, 184, 6, 163, 0, 1, 6, 156, 102, 166, 6, 158, 6, 163, 6, 157, 244, 164, 6, 158, 0, 0, 4, 112, 254, 175, 6, 157, 1, 0, 0, 0, 39, 175, 6, 156, 1, 0, 0, 0, 8, 184, 6, 163, 0, 1, 6, 156, 243, 166, 6, 158, 6, 163, 6, 157, 18, 164, 6, 158, 0, 0, 4, 112, 168, 175, 6, 157, 1, 0, 0, 0, 92, 175, 6, 156, 1, 0, 0, 0, 9, 184, 6, 163, 0, 1, 6, 156, 201, 166, 6, 158, 6, 163, 6, 157, 195, 164, 6, 158, 0, 0, 4, 112, 18, 175, 6, 157, 1, 0, 0, 0, 222, 175, 6, 156, 1, 0, 0, 0, 10, 184, 6, 163, 0, 1, 6, 156, 83, 166, 6, 158, 6, 163, 6, 157, 203, 164, 6, 158, 0, 0, 4, 112, 229, 175, 6, 157, 1, 0, 0, 0, 143, 175, 6, 156, 1, 0, 0, 0, 11, 184, 6, 163, 0, 1, 6, 156, 53, 166, 6, 158, 6, 163, 6, 157, 3, 164, 6, 158, 0, 0, 4, 112, 121, 175, 6, 157, 1, 0, 0, 0, 240, 175, 6, 156, 1, 0, 0, 0, 12, 184, 6, 163, 0, 1, 6, 156, 156, 166, 6, 158, 6, 163, 6, 157, 169, 164, 6, 158, 0, 0, 4, 112, 229, 175, 6, 157, 1, 0, 0, 0, 123, 175, 6, 156, 1, 0, 0, 0, 13, 184, 6, 163, 0, 1, 6, 156, 180, 166, 6, 158, 6, 163, 6, 157, 55, 164, 6, 158, 0, 0, 4, 112, 206, 175, 6, 157, 1, 0, 0, 0, 151, 175, 6, 156, 1, 0, 0, 0, 14, 184, 6, 163, 0, 1, 6, 156, 180, 166, 6, 158, 6, 163, 6, 157, 153, 164, 6, 158, 0, 0, 4, 112, 59, 175, 6, 157, 1, 0, 0, 0, 155, 175, 6, 156, 1, 0, 0, 0, 15, 184, 6, 163, 0, 1, 6, 156, 108, 166, 6, 158, 6, 163, 6, 157, 22, 164, 6, 158, 0, 0, 4, 112, 200, 175, 6, 157, 1, 0, 0, 0, 39, 175, 6, 156, 1, 0, 0, 0, 16, 184, 6, 163, 0, 1, 6, 156, 109, 166, 6, 158, 6, 163, 6, 157, 71, 164, 6, 158, 0, 0, 4, 112, 158, 175, 6, 157, 1, 0, 0, 0, 242, 175, 6, 156, 1, 0, 0, 0, 17, 184, 6, 163, 0, 1, 6, 156, 7, 166, 6, 158, 6, 163, 6, 157, 91, 164, 6, 158, 0, 0, 4, 112, 209, 175, 6, 157, 1, 0, 0, 0, 236, 175, 6, 156, 1, 0, 0, 0, 18, 184, 6, 163, 0, 1, 6, 156, 25, 166, 6, 158, 6, 163, 6, 157, 145, 164, 6, 158, 0, 0, 4, 112, 248, 175, 6, 157, 1, 0, 0, 0, 47, 175, 6, 156, 1, 0, 0, 0, 19, 184, 6, 163, 0, 1, 6, 156, 128, 166, 6, 158, 6, 163, 6, 157, 242, 164, 6, 158, 0, 0, 4, 112, 142, 175, 6, 157, 1, 0, 0, 0, 13, 175, 6, 156, 1, 0, 0, 0, 20, 184, 6, 163, 0, 1, 6, 156, 91, 166, 6, 158, 6, 163, 6, 157, 96, 164, 6, 158, 0, 0, 4, 112, 78, 175, 6, 162, 1, 0, 0, 0, 1, 161, 6, 162, 216, 242, 74, 129, 10, 175, 6, 162, 1, 0, 0, 0, 0, 161, 6, 162, 156, 207, 185, 62, 82]).buffer;
  function check(_0x1e008d) {
    let inputArray = _0x1e008d.split('').map(_0x60ff1a => _0x60ff1a.charCodeAt(0));
    
    // correct input array
    // inputArray = [85, 86, 84, 123, 67, 48, 110, 55, 114, 48, 49, 95, 70, 49, 48, 119, 95, 71, 48, 68, 125];
    
    inputArray = [0, 1, 2, 3, 4, 48, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 71, 18, 19, 20]

    let _0x11736b = check1(data, [inputArray]);

    return _0x11736b === 1;
  }
  let _0x2bdcee = document.getElementById("result");
  let _0x46f30c = document.getElementById('pw');
  let _0x1dca20 = document.getElementById("submit");
  _0x1dca20.onclick = function () {
    _0x2bdcee.classList.add("visible");
    if (_0x46f30c.value && check(_0x46f30c.value)) {
      _0x2bdcee.innerText = "Correct!";
    } else {
      _0x2bdcee.innerText = "Incorrect!";
    }
  };