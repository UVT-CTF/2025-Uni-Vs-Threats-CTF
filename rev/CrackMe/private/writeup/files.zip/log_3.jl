1	resultSet[1686] = -559038737;
1	resultSet[1685] = 0;
6	resultSet[1684] = 21[length] = 21
2	resultSet[1684] += -1; = 20
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 21
2	resultSet[1686] += -1640531527; = -2199570264
3	resultSet[1686] ^= resultSet[1686](2095400013) >>> 16; = 2095400013
4	resultSet[1686] = Math.imul(resultSet[1686](-1686484471), 569420461); = -1686484471
3	resultSet[1686] ^= resultSet[1686](-1686405891) >>> 15; = -1686405891
4	resultSet[1686] = Math.imul(resultSet[1686](46215739), 1935289751); = 46215739
3	resultSet[1686] ^= resultSet[1686](46217145) >>> 15; = 46217145
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 9
5	resultSet[1690] >= 0
14	swapping vals a[9], a[20] where a = resultSet[1](0,1,2,3,4,48,6,7,8,20,10,11,12,13,14,15,16,71,18,19,9); b = resultSet[1690](9); c = resultSet[1684](20)
2	resultSet[1686] += -1640531527; = -1594314382
3	resultSet[1686] ^= resultSet[1686](-1594355318) >>> 16; = -1594355318
4	resultSet[1686] = Math.imul(resultSet[1686](-1096188350), 569420461); = -1096188350
3	resultSet[1686] ^= resultSet[1686](-1096285424) >>> 15; = -1096285424
4	resultSet[1686] = Math.imul(resultSet[1686](1094950512), 1935289751); = 1094950512
3	resultSet[1686] ^= resultSet[1686](1094917367) >>> 15; = 1094917367
22	resultSet[1689] = resultSet[1][resultSet[1684](20)]; = 9
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 273729341
30	resultSet[1689] ^= resultSet[1688](273729341) = 273729332
29	resultSet[1689] &= 255 = 52
32	resultSet[1][resultSet[1684](20)] = resultSet[1689]52;
2	resultSet[1684] += -1; = 19
7	resultSet[1694] = 19(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 20
2	resultSet[1686] += -1640531527; = -545614160
3	resultSet[1686] ^= resultSet[1686](-545633846) >>> 16; = -545633846
4	resultSet[1686] = Math.imul(resultSet[1686](1912865154), 569420461); = 1912865154
3	resultSet[1686] ^= resultSet[1686](1912923530) >>> 15; = 1912923530
4	resultSet[1686] = Math.imul(resultSet[1686](-843012506), 1935289751); = -843012506
3	resultSet[1686] ^= resultSet[1686](-842973721) >>> 15; = -842973721
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -1
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](1) = 1
14	swapping vals a[1], a[19] where a = resultSet[1](0,19,2,3,4,48,6,7,8,20,10,11,12,13,14,15,16,71,18,1,52); b = resultSet[1690](1); c = resultSet[1684](19)
2	resultSet[1686] += -1640531527; = -2483505248
3	resultSet[1686] ^= resultSet[1686](1811471448) >>> 16; = 1811471448
4	resultSet[1686] = Math.imul(resultSet[1686](603936632), 569420461); = 603936632
3	resultSet[1686] ^= resultSet[1686](603918470) >>> 15; = 603918470
4	resultSet[1686] = Math.imul(resultSet[1686](309742858), 1935289751); = 309742858
3	resultSet[1686] ^= resultSet[1686](309750246) >>> 15; = 309750246
22	resultSet[1689] = resultSet[1][resultSet[1684](19)]; = 1
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 77437561
30	resultSet[1689] ^= resultSet[1688](77437561) = 77437560
29	resultSet[1689] &= 255 = 120
32	resultSet[1][resultSet[1684](19)] = resultSet[1689]120;
2	resultSet[1684] += -1; = 18
7	resultSet[1694] = 18(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 19
2	resultSet[1686] += -1640531527; = -1330781281
3	resultSet[1686] ^= resultSet[1686](-1330818254) >>> 16; = -1330818254
4	resultSet[1686] = Math.imul(resultSet[1686](-280990518), 569420461); = -280990518
3	resultSet[1686] ^= resultSet[1686](-280907190) >>> 15; = -280907190
4	resultSet[1686] = Math.imul(resultSet[1686](-1743049818), 1935289751); = -1743049818
3	resultSet[1686] ^= resultSet[1686](-1743119472) >>> 15; = -1743119472
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -2
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](2) = 2
14	swapping vals a[2], a[18] where a = resultSet[1](0,19,18,3,4,48,6,7,8,20,10,11,12,13,14,15,16,71,2,120,52); b = resultSet[1690](2); c = resultSet[1684](18)
2	resultSet[1686] += -1640531527; = -3383650999
3	resultSet[1686] ^= resultSet[1686](911319832) >>> 16; = 911319832
4	resultSet[1686] = Math.imul(resultSet[1686](-369547464), 569420461); = -369547464
3	resultSet[1686] ^= resultSet[1686](-369560374) >>> 15; = -369560374
4	resultSet[1686] = Math.imul(resultSet[1686](-1847335642), 1935289751); = -1847335642
3	resultSet[1686] ^= resultSet[1686](-1847408927) >>> 15; = -1847408927
22	resultSet[1689] = resultSet[1][resultSet[1684](18)]; = 2
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 611889592
30	resultSet[1689] ^= resultSet[1688](611889592) = 611889594
29	resultSet[1689] &= 255 = 186
32	resultSet[1][resultSet[1684](18)] = resultSet[1689]186;
2	resultSet[1684] += -1; = 17
7	resultSet[1694] = 17(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 18
2	resultSet[1686] += -1640531527; = -3487940454
3	resultSet[1686] ^= resultSet[1686](807039104) >>> 16; = 807039104
4	resultSet[1686] = Math.imul(resultSet[1686](143853184), 569420461); = 143853184
3	resultSet[1686] ^= resultSet[1686](143857574) >>> 15; = 143857574
4	resultSet[1686] = Math.imul(resultSet[1686](-867753750), 1935289751); = -867753750
3	resultSet[1686] ^= resultSet[1686](-867780508) >>> 15; = -867780508
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -4
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](4) = 4
14	swapping vals a[4], a[17] where a = resultSet[1](0,19,18,3,71,48,6,7,8,20,10,11,12,13,14,15,16,4,186,120,52); b = resultSet[1690](4); c = resultSet[1684](17)
2	resultSet[1686] += -1640531527; = -2508312035
3	resultSet[1686] ^= resultSet[1686](1786665059) >>> 16; = 1786665059
4	resultSet[1686] = Math.imul(resultSet[1686](2112059623), 569420461); = 2112059623
3	resultSet[1686] ^= resultSet[1686](2112062241) >>> 15; = 2112062241
4	resultSet[1686] = Math.imul(resultSet[1686](735651191), 1935289751); = 735651191
3	resultSet[1686] ^= resultSet[1686](735670981) >>> 15; = 735670981
22	resultSet[1689] = resultSet[1][resultSet[1684](17)]; = 4
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 183917745
30	resultSet[1689] ^= resultSet[1688](183917745) = 183917749
29	resultSet[1689] &= 255 = 181
32	resultSet[1][resultSet[1684](17)] = resultSet[1689]181;
2	resultSet[1684] += -1; = 16
7	resultSet[1694] = 16(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 17
2	resultSet[1686] += -1640531527; = -904860546
3	resultSet[1686] ^= resultSet[1686](-904911250) >>> 16; = -904911250
4	resultSet[1686] = Math.imul(resultSet[1686](2072970326), 569420461); = 2072970326
3	resultSet[1686] ^= resultSet[1686](2073031496) >>> 15; = 2073031496
4	resultSet[1686] = Math.imul(resultSet[1686](251406200), 1935289751); = 251406200
3	resultSet[1686] ^= resultSet[1686](251411072) >>> 15; = 251411072
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 10
5	resultSet[1690] >= 0
14	swapping vals a[10], a[16] where a = resultSet[1](0,19,18,3,71,48,6,7,8,20,16,11,12,13,14,15,10,181,186,120,52); b = resultSet[1690](10); c = resultSet[1684](16)
2	resultSet[1686] += -1640531527; = -1389120455
3	resultSet[1686] ^= resultSet[1686](-1389160182) >>> 16; = -1389160182
4	resultSet[1686] = Math.imul(resultSet[1686](-1115123774), 569420461); = -1115123774
3	resultSet[1686] ^= resultSet[1686](-1115032365) >>> 15; = -1115032365
4	resultSet[1686] = Math.imul(resultSet[1686](-409567371), 1935289751); = -409567371
3	resultSet[1686] ^= resultSet[1686](-409489319) >>> 15; = -409489319
22	resultSet[1689] = resultSet[1][resultSet[1684](16)]; = 10
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 971369494
30	resultSet[1689] ^= resultSet[1688](971369494) = 971369500
29	resultSet[1689] &= 255 = 28
32	resultSet[1][resultSet[1684](16)] = resultSet[1689]28;
2	resultSet[1684] += -1; = 15
7	resultSet[1694] = 15(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 16
2	resultSet[1686] += -1640531527; = -2050020846
3	resultSet[1686] ^= resultSet[1686](-2049986595) >>> 16; = -2049986595
4	resultSet[1686] = Math.imul(resultSet[1686](-1269654951), 569420461); = -1269654951
3	resultSet[1686] ^= resultSet[1686](-1269566724) >>> 15; = -1269566724
4	resultSet[1686] = Math.imul(resultSet[1686](-1076715868), 1935289751); = -1076715868
3	resultSet[1686] ^= resultSet[1686](-1076633343) >>> 15; = -1076633343
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -15
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](15) = 15
14	swapping vals a[15], a[15] where a = resultSet[1](0,19,18,3,71,48,6,7,8,20,16,11,12,13,14,15,28,181,186,120,52); b = resultSet[1690](15); c = resultSet[1684](15)
2	resultSet[1686] += -1640531527; = -2717164870
3	resultSet[1686] ^= resultSet[1686](1577780401) >>> 16; = 1577780401
4	resultSet[1686] = Math.imul(resultSet[1686](360691101), 569420461); = 360691101
3	resultSet[1686] ^= resultSet[1686](360685410) >>> 15; = 360685410
4	resultSet[1686] = Math.imul(resultSet[1686](733953230), 1935289751); = 733953230
3	resultSet[1686] ^= resultSet[1686](733965232) >>> 15; = 733965232
22	resultSet[1689] = resultSet[1][resultSet[1684](15)]; = 15
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 183491308
30	resultSet[1689] ^= resultSet[1688](183491308) = 183491299
29	resultSet[1689] &= 255 = 227
32	resultSet[1][resultSet[1684](15)] = resultSet[1689]227;
2	resultSet[1684] += -1; = 14
7	resultSet[1694] = 14(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 15
2	resultSet[1686] += -1640531527; = -906566295
3	resultSet[1686] ^= resultSet[1686](-906613601) >>> 16; = -906613601
4	resultSet[1686] = Math.imul(resultSet[1686](1225637235), 569420461); = 1225637235
3	resultSet[1686] ^= resultSet[1686](1225600872) >>> 15; = 1225600872
4	resultSet[1686] = Math.imul(resultSet[1686](-894681512), 1935289751); = -894681512
3	resultSet[1686] ^= resultSet[1686](-894588160) >>> 15; = -894588160
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -10
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](10) = 10
14	swapping vals a[10], a[14] where a = resultSet[1](0,19,18,3,71,48,6,7,8,20,14,11,12,13,16,227,28,181,186,120,52); b = resultSet[1690](10); c = resultSet[1684](14)
2	resultSet[1686] += -1640531527; = -2535119687
3	resultSet[1686] ^= resultSet[1686](1759857756) >>> 16; = 1759857756
4	resultSet[1686] = Math.imul(resultSet[1686](-1712737748), 569420461); = -1712737748
3	resultSet[1686] ^= resultSet[1686](-1712815617) >>> 15; = -1712815617
4	resultSet[1686] = Math.imul(resultSet[1686](-408649623), 1935289751); = -408649623
3	resultSet[1686] ^= resultSet[1686](-408596704) >>> 15; = -408596704
22	resultSet[1689] = resultSet[1][resultSet[1684](14)]; = 16
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 971592648
30	resultSet[1689] ^= resultSet[1688](971592648) = 971592664
29	resultSet[1689] &= 255 = 216
32	resultSet[1][resultSet[1684](14)] = resultSet[1689]216;
2	resultSet[1684] += -1; = 13
7	resultSet[1694] = 13(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 14
2	resultSet[1686] += -1640531527; = -2049128231
3	resultSet[1686] ^= resultSet[1686](-2049159931) >>> 16; = -2049159931
4	resultSet[1686] = Math.imul(resultSet[1686](-1699389855), 569420461); = -1699389855
3	resultSet[1686] ^= resultSet[1686](-1699452149) >>> 15; = -1699452149
4	resultSet[1686] = Math.imul(resultSet[1686](-1978002819), 1935289751); = -1978002819
3	resultSet[1686] ^= resultSet[1686](-1977940407) >>> 15; = -1977940407
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -9
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](9) = 9
14	swapping vals a[9], a[13] where a = resultSet[1](0,19,18,3,71,48,6,7,8,13,14,11,12,20,216,227,28,181,186,120,52); b = resultSet[1690](9); c = resultSet[1684](13)
2	resultSet[1686] += -1640531527; = -3618471934
3	resultSet[1686] ^= resultSet[1686](676505680) >>> 16; = 676505680
4	resultSet[1686] = Math.imul(resultSet[1686](1050730000), 569420461); = 1050730000
3	resultSet[1686] ^= resultSet[1686](1050714961) >>> 15; = 1050714961
4	resultSet[1686] = Math.imul(resultSet[1686](-84962873), 1935289751); = -84962873
3	resultSet[1686] ^= resultSet[1686](-85040104) >>> 15; = -85040104
22	resultSet[1689] = resultSet[1][resultSet[1684](13)]; = 20
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 1052481798
30	resultSet[1689] ^= resultSet[1688](1052481798) = 1052481810
29	resultSet[1689] &= 255 = 18
32	resultSet[1][resultSet[1684](13)] = resultSet[1689]18;
2	resultSet[1684] += -1; = 12
7	resultSet[1694] = 12(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 13
2	resultSet[1686] += -1640531527; = -1725571631
3	resultSet[1686] ^= resultSet[1686](-1725610764) >>> 16; = -1725610764
4	resultSet[1686] = Math.imul(resultSet[1686](1455005924), 569420461); = 1455005924
3	resultSet[1686] ^= resultSet[1686](1454968215) >>> 15; = 1454968215
4	resultSet[1686] = Math.imul(resultSet[1686](1252036369), 1935289751); = 1252036369
3	resultSet[1686] ^= resultSet[1686](1252006480) >>> 15; = 1252006480
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 10
5	resultSet[1690] >= 0
14	swapping vals a[10], a[12] where a = resultSet[1](0,19,18,3,71,48,6,7,8,13,12,11,14,18,216,227,28,181,186,120,52); b = resultSet[1690](10); c = resultSet[1684](12)
2	resultSet[1686] += -1640531527; = -388525047
3	resultSet[1686] ^= resultSet[1686](-388530978) >>> 16; = -388530978
4	resultSet[1686] = Math.imul(resultSet[1686](548064774), 569420461); = 548064774
3	resultSet[1686] ^= resultSet[1686](548048723) >>> 15; = 548048723
4	resultSet[1686] = Math.imul(resultSet[1686](-335929099), 1935289751); = -335929099
3	resultSet[1686] ^= resultSet[1686](-335808767) >>> 15; = -335808767
22	resultSet[1689] = resultSet[1][resultSet[1684](12)]; = 14
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 989789632
30	resultSet[1689] ^= resultSet[1688](989789632) = 989789646
29	resultSet[1689] &= 255 = 206
32	resultSet[1][resultSet[1684](12)] = resultSet[1689]206;
2	resultSet[1684] += -1; = 11
7	resultSet[1694] = 11(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 12
2	resultSet[1686] += -1640531527; = -1976340294
3	resultSet[1686] ^= resultSet[1686](-1976305015) >>> 16; = -1976305015
4	resultSet[1686] = Math.imul(resultSet[1686](1928284309), 569420461); = 1928284309
3	resultSet[1686] ^= resultSet[1686](1928310091) >>> 15; = 1928310091
4	resultSet[1686] = Math.imul(resultSet[1686](-1976342979), 1935289751); = -1976342979
3	resultSet[1686] ^= resultSet[1686](-1976405413) >>> 15; = -1976405413
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -1
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](1) = 1
14	swapping vals a[1], a[11] where a = resultSet[1](0,11,18,3,71,48,6,7,8,13,12,19,206,18,216,227,28,181,186,120,52); b = resultSet[1690](1); c = resultSet[1684](11)
2	resultSet[1686] += -1640531527; = -3616936940
3	resultSet[1686] ^= resultSet[1686](678020221) >>> 16; = 678020221
4	resultSet[1686] = Math.imul(resultSet[1686](-568014215), 569420461); = -568014215
3	resultSet[1686] ^= resultSet[1686](-567970256) >>> 15; = -567970256
4	resultSet[1686] = Math.imul(resultSet[1686](-1161877936), 1935289751); = -1161877936
3	resultSet[1686] ^= resultSet[1686](-1161931986) >>> 15; = -1161931986
22	resultSet[1689] = resultSet[1][resultSet[1684](11)]; = 19
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 783258827
30	resultSet[1689] ^= resultSet[1688](783258827) = 783258840
29	resultSet[1689] &= 255 = 216
32	resultSet[1][resultSet[1684](11)] = resultSet[1689]216;
2	resultSet[1684] += -1; = 10
7	resultSet[1694] = 10(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 11
2	resultSet[1686] += -1640531527; = -2802463513
3	resultSet[1686] ^= resultSet[1686](1492489234) >>> 16; = 1492489234
4	resultSet[1686] = Math.imul(resultSet[1686](1428751402), 569420461); = 1428751402
3	resultSet[1686] ^= resultSet[1686](1428795000) >>> 15; = 1428795000
4	resultSet[1686] = Math.imul(resultSet[1686](-848232248), 1935289751); = -848232248
3	resultSet[1686] ^= resultSet[1686](-848258518) >>> 15; = -848258518
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -8
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](8) = 8
14	swapping vals a[8], a[10] where a = resultSet[1](0,11,18,3,71,48,6,7,12,13,8,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](8); c = resultSet[1684](10)
2	resultSet[1686] += -1640531527; = -2488790045
3	resultSet[1686] ^= resultSet[1686](1806202955) >>> 16; = 1806202955
4	resultSet[1686] = Math.imul(resultSet[1686](302717103), 569420461); = 302717103
3	resultSet[1686] ^= resultSet[1686](302726329) >>> 15; = 302726329
4	resultSet[1686] = Math.imul(resultSet[1686](307713567), 1935289751); = 307713567
3	resultSet[1686] ^= resultSet[1686](307720881) >>> 15; = 307720881
22	resultSet[1689] = resultSet[1][resultSet[1684](10)]; = 8
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 76930220
30	resultSet[1689] ^= resultSet[1688](76930220) = 76930212
29	resultSet[1689] &= 255 = 164
32	resultSet[1][resultSet[1684](10)] = resultSet[1689]164;
2	resultSet[1684] += -1; = 9
7	resultSet[1694] = 9(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 10
2	resultSet[1686] += -1640531527; = -1332810646
3	resultSet[1686] ^= resultSet[1686](-1332847388) >>> 16; = -1332847388
4	resultSet[1686] = Math.imul(resultSet[1686](1403268628), 569420461); = 1403268628
3	resultSet[1686] ^= resultSet[1686](1403291996) >>> 15; = 1403291996
4	resultSet[1686] = Math.imul(resultSet[1686](-527814332), 1935289751); = -527814332
3	resultSet[1686] ^= resultSet[1686](-527699888) >>> 15; = -527699888
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -8
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](8) = 8
14	swapping vals a[8], a[9] where a = resultSet[1](0,11,18,3,71,48,6,7,13,12,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](8); c = resultSet[1684](9)
2	resultSet[1686] += -1640531527; = -2168231415
3	resultSet[1686] ^= resultSet[1686](2126714058) >>> 16; = 2126714058
4	resultSet[1686] = Math.imul(resultSet[1686](-1123864446), 569420461); = -1123864446
3	resultSet[1686] ^= resultSet[1686](-1123923324) >>> 15; = -1123923324
4	resultSet[1686] = Math.imul(resultSet[1686](1641752540), 1935289751); = 1641752540
3	resultSet[1686] ^= resultSet[1686](1641800810) >>> 15; = 1641800810
22	resultSet[1689] = resultSet[1][resultSet[1684](9)]; = 12
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 410450202
30	resultSet[1689] ^= resultSet[1688](410450202) = 410450198
29	resultSet[1689] &= 255 = 22
32	resultSet[1][resultSet[1684](9)] = resultSet[1689]22;
2	resultSet[1684] += -1; = 8
7	resultSet[1694] = 8(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 9
2	resultSet[1686] += -1640531527; = 1269283
3	resultSet[1686] ^= resultSet[1686](1269296) >>> 16; = 1269296
4	resultSet[1686] = Math.imul(resultSet[1686](1721927280), 569420461); = 1721927280
3	resultSet[1686] ^= resultSet[1686](1721912117) >>> 15; = 1721912117
4	resultSet[1686] = Math.imul(resultSet[1686](1351920963), 1935289751); = 1351920963
3	resultSet[1686] ^= resultSet[1686](1351879786) >>> 15; = 1351879786
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 1
5	resultSet[1690] >= 0
14	swapping vals a[1], a[8] where a = resultSet[1](0,13,18,3,71,48,6,7,11,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](1); c = resultSet[1684](8)
2	resultSet[1686] += -1640531527; = -288651741
3	resultSet[1686] ^= resultSet[1686](-288659224) >>> 16; = -288659224
4	resultSet[1686] = Math.imul(resultSet[1686](-1264585528), 569420461); = -1264585528
3	resultSet[1686] ^= resultSet[1686](-1264673289) >>> 15; = -1264673289
4	resultSet[1686] = Math.imul(resultSet[1686](-383150159), 1935289751); = -383150159
3	resultSet[1686] ^= resultSet[1686](-383236638) >>> 15; = -383236638
22	resultSet[1689] = resultSet[1][resultSet[1684](8)]; = 11
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 977932664
30	resultSet[1689] ^= resultSet[1688](977932664) = 977932659
29	resultSet[1689] &= 255 = 115
32	resultSet[1][resultSet[1684](8)] = resultSet[1689]115;
2	resultSet[1684] += -1; = 7
7	resultSet[1694] = 7(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 8
2	resultSet[1686] += -1640531527; = -2023768165
3	resultSet[1686] ^= resultSet[1686](-2023802684) >>> 16; = -2023802684
4	resultSet[1686] = Math.imul(resultSet[1686](852198516), 569420461); = 852198516
3	resultSet[1686] ^= resultSet[1686](852222435) >>> 15; = 852222435
4	resultSet[1686] = Math.imul(resultSet[1686](801448933), 1935289751); = 801448933
3	resultSet[1686] ^= resultSet[1686](801471599) >>> 15; = 801471599
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 7
5	resultSet[1690] >= 0
14	swapping vals a[7], a[7] where a = resultSet[1](0,13,18,3,71,48,6,7,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](7); c = resultSet[1684](7)
2	resultSet[1686] += -1640531527; = -839059928
3	resultSet[1686] ^= resultSet[1686](-839107628) >>> 16; = -839107628
4	resultSet[1686] = Math.imul(resultSet[1686](502216260), 569420461); = 502216260
3	resultSet[1686] ^= resultSet[1686](502205850) >>> 15; = 502205850
4	resultSet[1686] = Math.imul(resultSet[1686](-1551296554), 1935289751); = -1551296554
3	resultSet[1686] ^= resultSet[1686](-1551347516) >>> 15; = -1551347516
22	resultSet[1689] = resultSet[1][resultSet[1684](7)]; = 7
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 685904945
30	resultSet[1689] ^= resultSet[1688](685904945) = 685904950
29	resultSet[1689] &= 255 = 54
32	resultSet[1][resultSet[1684](7)] = resultSet[1689]54;
2	resultSet[1684] += -1; = 6
7	resultSet[1694] = 6(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 7
2	resultSet[1686] += -1640531527; = -3191879043
3	resultSet[1686] ^= resultSet[1686](1103072194) >>> 16; = 1103072194
4	resultSet[1686] = Math.imul(resultSet[1686](-1457502694), 569420461); = -1457502694
3	resultSet[1686] ^= resultSet[1686](-1457449894) >>> 15; = -1457449894
4	resultSet[1686] = Math.imul(resultSet[1686](683332374), 1935289751); = 683332374
3	resultSet[1686] ^= resultSet[1686](683311715) >>> 15; = 683311715
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 2
5	resultSet[1690] >= 0
14	swapping vals a[2], a[6] where a = resultSet[1](0,13,6,3,71,48,18,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](2); c = resultSet[1684](6)
2	resultSet[1686] += -1640531527; = -957219812
3	resultSet[1686] ^= resultSet[1686](-957269267) >>> 16; = -957269267
4	resultSet[1686] = Math.imul(resultSet[1686](1834365993), 569420461); = 1834365993
3	resultSet[1686] ^= resultSet[1686](1834413701) >>> 15; = 1834413701
4	resultSet[1686] = Math.imul(resultSet[1686](1609961843), 1935289751); = 1609961843
3	resultSet[1686] ^= resultSet[1686](1610002079) >>> 15; = 1610002079
22	resultSet[1689] = resultSet[1][resultSet[1684](6)]; = 18
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 402500519
30	resultSet[1689] ^= resultSet[1688](402500519) = 402500533
29	resultSet[1689] &= 255 = 181
32	resultSet[1][resultSet[1684](6)] = resultSet[1689]181;
2	resultSet[1684] += -1; = 5
7	resultSet[1694] = 5(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 6
2	resultSet[1686] += -1640531527; = -30529448
3	resultSet[1686] ^= resultSet[1686](-30484874) >>> 16; = -30484874
4	resultSet[1686] = Math.imul(resultSet[1686](615598526), 569420461); = 615598526
3	resultSet[1686] ^= resultSet[1686](615579868) >>> 15; = 615579868
4	resultSet[1686] = Math.imul(resultSet[1686](-488231484), 1935289751); = -488231484
3	resultSet[1686] ^= resultSet[1686](-488118264) >>> 15; = -488118264
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 0
5	resultSet[1690] >= 0
14	swapping vals a[0], a[5] where a = resultSet[1](48,13,6,3,71,0,181,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](0); c = resultSet[1684](5)
2	resultSet[1686] += -1640531527; = -2128649791
3	resultSet[1686] ^= resultSet[1686](-2128617250) >>> 16; = -2128617250
4	resultSet[1686] = Math.imul(resultSet[1686](-604085754), 569420461); = -604085754
3	resultSet[1686] ^= resultSet[1686](-603990534) >>> 15; = -603990534
4	resultSet[1686] = Math.imul(resultSet[1686](1147676790), 1935289751); = 1147676790
3	resultSet[1686] ^= resultSet[1686](1147707558) >>> 15; = 1147707558
22	resultSet[1689] = resultSet[1][resultSet[1684](5)]; = 0
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 286926889
30	resultSet[1689] ^= resultSet[1688](286926889) = 286926889
29	resultSet[1689] &= 255 = 41
32	resultSet[1][resultSet[1684](5)] = resultSet[1689]41;
2	resultSet[1684] += -1; = 4
7	resultSet[1694] = 4(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 5
2	resultSet[1686] += -1640531527; = -492823969
3	resultSet[1686] ^= resultSet[1686](-492766977) >>> 16; = -492766977
4	resultSet[1686] = Math.imul(resultSet[1686](1513200211), 569420461); = 1513200211
3	resultSet[1686] ^= resultSet[1686](1513172528) >>> 15; = 1513172528
4	resultSet[1686] = Math.imul(resultSet[1686](-1526682032), 1935289751); = -1526682032
3	resultSet[1686] ^= resultSet[1686](-1526602671) >>> 15; = -1526602671
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -1
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](1) = 1
14	swapping vals a[1], a[4] where a = resultSet[1](48,71,6,3,13,41,181,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](1); c = resultSet[1684](4)
2	resultSet[1686] += -1640531527; = -3167134198
3	resultSet[1686] ^= resultSet[1686](1127816499) >>> 16; = 1127816499
4	resultSet[1686] = Math.imul(resultSet[1686](1305254263), 569420461); = 1305254263
3	resultSet[1686] ^= resultSet[1686](1305215726) >>> 15; = 1305215726
4	resultSet[1686] = Math.imul(resultSet[1686](-1316646814), 1935289751); = -1316646814
3	resultSet[1686] ^= resultSet[1686](-1316686999) >>> 15; = -1316686999
22	resultSet[1689] = resultSet[1][resultSet[1684](4)]; = 13
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 744570074
30	resultSet[1689] ^= resultSet[1688](744570074) = 744570071
29	resultSet[1689] &= 255 = 215
32	resultSet[1][resultSet[1684](4)] = resultSet[1689]215;
2	resultSet[1684] += -1; = 3
7	resultSet[1694] = 3(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 4
2	resultSet[1686] += -1640531527; = -2957218526
3	resultSet[1686] ^= resultSet[1686](1337729694) >>> 16; = 1337729694
4	resultSet[1686] = Math.imul(resultSet[1686](-1556066106), 569420461); = -1556066106
3	resultSet[1686] ^= resultSet[1686](-1556015546) >>> 15; = -1556015546
4	resultSet[1686] = Math.imul(resultSet[1686](48918858), 1935289751); = 48918858
3	resultSet[1686] ^= resultSet[1686](48919710) >>> 15; = 48919710
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 2
5	resultSet[1690] >= 0
14	swapping vals a[2], a[3] where a = resultSet[1](48,71,3,6,215,41,181,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](2); c = resultSet[1684](3)
2	resultSet[1686] += -1640531527; = -1591611817
3	resultSet[1686] ^= resultSet[1686](-1591652490) >>> 16; = -1591652490
4	resultSet[1686] = Math.imul(resultSet[1686](-1226371394), 569420461); = -1226371394
3	resultSet[1686] ^= resultSet[1686](-1226415248) >>> 15; = -1226415248
4	resultSet[1686] = Math.imul(resultSet[1686](-1497409776), 1935289751); = -1497409776
3	resultSet[1686] ^= resultSet[1686](-1497490834) >>> 15; = -1497490834
22	resultSet[1689] = resultSet[1][resultSet[1684](3)]; = 6
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 699369115
30	resultSet[1689] ^= resultSet[1688](699369115) = 699369117
29	resultSet[1689] &= 255 = 157
32	resultSet[1][resultSet[1684](3)] = resultSet[1689]157;
2	resultSet[1684] += -1; = 2
7	resultSet[1694] = 2(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 3
2	resultSet[1686] += -1640531527; = -3138022361
3	resultSet[1686] ^= resultSet[1686](1156960466) >>> 16; = 1156960466
4	resultSet[1686] = Math.imul(resultSet[1686](-1381395990), 569420461); = -1381395990
3	resultSet[1686] ^= resultSet[1686](-1381446983) >>> 15; = -1381446983
4	resultSet[1686] = Math.imul(resultSet[1686](2050758687), 1935289751); = 2050758687
3	resultSet[1686] ^= resultSet[1686](2050813031) >>> 15; = 2050813031
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 2
5	resultSet[1690] >= 0
14	swapping vals a[2], a[2] where a = resultSet[1](48,71,3,157,215,41,181,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](2); c = resultSet[1684](2)
2	resultSet[1686] += -1640531527; = 410281504
3	resultSet[1686] ^= resultSet[1686](410287700) >>> 16; = 410287700
4	resultSet[1686] = Math.imul(resultSet[1686](626861764), 569420461); = 626861764
3	resultSet[1686] ^= resultSet[1686](626879614) >>> 15; = 626879614
4	resultSet[1686] = Math.imul(resultSet[1686](880354386), 1935289751); = 880354386
3	resultSet[1686] ^= resultSet[1686](880364704) >>> 15; = 880364704
22	resultSet[1689] = resultSet[1][resultSet[1684](2)]; = 3
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 220091176
30	resultSet[1689] ^= resultSet[1688](220091176) = 220091179
29	resultSet[1689] &= 255 = 43
32	resultSet[1][resultSet[1684](2)] = resultSet[1689]43;
2	resultSet[1684] += -1; = 1
7	resultSet[1694] = 1(resultSet[1684]) > 0(resultSet[1685]) = true
11	true(!resultSet[1694]); setting PS.offset to 56
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 2
2	resultSet[1686] += -1640531527; = -760166823
3	resultSet[1686] ^= resultSet[1686](-760212247) >>> 16; = -760212247
4	resultSet[1686] = Math.imul(resultSet[1686](-229581963), 569420461); = -229581963
3	resultSet[1686] ^= resultSet[1686](-229556268) >>> 15; = -229556268
4	resultSet[1686] = Math.imul(resultSet[1686](-491984372), 1935289751); = -491984372
3	resultSet[1686] ^= resultSet[1686](-491966635) >>> 15; = -491966635
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = -1
5	resultSet[1690] < 0; resultSet[1690] = -resultSet[1690](1) = 1
14	swapping vals a[1], a[1] where a = resultSet[1](48,71,43,157,215,41,181,54,115,22,164,216,206,18,216,227,28,181,186,120,52); b = resultSet[1690](1); c = resultSet[1684](1)
2	resultSet[1686] += -1640531527; = -2132498162
3	resultSet[1686] ^= resultSet[1686](-2132530710) >>> 16; = -2132530710
4	resultSet[1686] = Math.imul(resultSet[1686](325433122), 569420461); = 325433122
3	resultSet[1686] ^= resultSet[1686](325423593) >>> 15; = 325423593
4	resultSet[1686] = Math.imul(resultSet[1686](1115227503), 1935289751); = 1115227503
3	resultSet[1686] ^= resultSet[1686](1115259293) >>> 15; = 1115259293
22	resultSet[1689] = resultSet[1][resultSet[1684](1)]; = 71
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 278814823
30	resultSet[1689] ^= resultSet[1688](278814823) = 278814752
29	resultSet[1689] &= 255 = 32
32	resultSet[1][resultSet[1684](1)] = resultSet[1689]32;
2	resultSet[1684] += -1; = 0
7	resultSet[1694] = 0(resultSet[1684]) > 0(resultSet[1685]) = false
11	false(!resultSet[1694])
1	resultSet[1693] = 48;
1	resultSet[1692] = 0;
22	resultSet[1699] = resultSet[1][resultSet[1692](0)]; = 48
		checking equals to 48
8	resultSet[1694] = 48(resultSet[1699]) === 48(resultSet[1693]) = true
1	resultSet[1693] = 32;
1	resultSet[1692] = 1;
22	resultSet[1699] = resultSet[1][resultSet[1692](1)]; = 32
		checking equals to 32
8	resultSet[1694] = 32(resultSet[1699]) === 32(resultSet[1693]) = true
1	resultSet[1693] = 83;
1	resultSet[1692] = 2;
# EXAMPLE given in the writeup
22	resultSet[1699] = resultSet[1][resultSet[1692](2)]; = 43
		checking equals to 83
8	resultSet[1694] = 43(resultSet[1699]) === 83(resultSet[1693]) = false
1	resultSet[1693] = 245;
1	resultSet[1692] = 3;
22	resultSet[1699] = resultSet[1][resultSet[1692](3)]; = 157
		checking equals to 245
8	resultSet[1694] = 157(resultSet[1699]) === 245(resultSet[1693]) = false
1	resultSet[1693] = 235;
1	resultSet[1692] = 4;
22	resultSet[1699] = resultSet[1][resultSet[1692](4)]; = 215
		checking equals to 235
8	resultSet[1694] = 215(resultSet[1699]) === 235(resultSet[1693]) = false
1	resultSet[1693] = 124;
1	resultSet[1692] = 5;
22	resultSet[1699] = resultSet[1][resultSet[1692](5)]; = 41
		checking equals to 124
8	resultSet[1694] = 41(resultSet[1699]) === 124(resultSet[1693]) = false
1	resultSet[1693] = 151;
1	resultSet[1692] = 6;
22	resultSet[1699] = resultSet[1][resultSet[1692](6)]; = 181
		checking equals to 151
8	resultSet[1694] = 181(resultSet[1699]) === 151(resultSet[1693]) = false
1	resultSet[1693] = 6;
1	resultSet[1692] = 7;
22	resultSet[1699] = resultSet[1][resultSet[1692](7)]; = 54
		checking equals to 6
8	resultSet[1694] = 54(resultSet[1699]) === 6(resultSet[1693]) = false
1	resultSet[1693] = 39;
1	resultSet[1692] = 8;
22	resultSet[1699] = resultSet[1][resultSet[1692](8)]; = 115
		checking equals to 39
8	resultSet[1694] = 115(resultSet[1699]) === 39(resultSet[1693]) = false
1	resultSet[1693] = 92;
1	resultSet[1692] = 9;
22	resultSet[1699] = resultSet[1][resultSet[1692](9)]; = 22
		checking equals to 92
8	resultSet[1694] = 22(resultSet[1699]) === 92(resultSet[1693]) = false
1	resultSet[1693] = 222;
1	resultSet[1692] = 10;
22	resultSet[1699] = resultSet[1][resultSet[1692](10)]; = 164
		checking equals to 222
8	resultSet[1694] = 164(resultSet[1699]) === 222(resultSet[1693]) = false
1	resultSet[1693] = 143;
1	resultSet[1692] = 11;
22	resultSet[1699] = resultSet[1][resultSet[1692](11)]; = 216
		checking equals to 143
8	resultSet[1694] = 216(resultSet[1699]) === 143(resultSet[1693]) = false
1	resultSet[1693] = 240;
1	resultSet[1692] = 12;
22	resultSet[1699] = resultSet[1][resultSet[1692](12)]; = 206
		checking equals to 240
8	resultSet[1694] = 206(resultSet[1699]) === 240(resultSet[1693]) = false
1	resultSet[1693] = 123;
1	resultSet[1692] = 13;
22	resultSet[1699] = resultSet[1][resultSet[1692](13)]; = 18
		checking equals to 123
8	resultSet[1694] = 18(resultSet[1699]) === 123(resultSet[1693]) = false
1	resultSet[1693] = 151;
1	resultSet[1692] = 14;
22	resultSet[1699] = resultSet[1][resultSet[1692](14)]; = 216
		checking equals to 151
8	resultSet[1694] = 216(resultSet[1699]) === 151(resultSet[1693]) = false
1	resultSet[1693] = 155;
1	resultSet[1692] = 15;
22	resultSet[1699] = resultSet[1][resultSet[1692](15)]; = 227
		checking equals to 155
8	resultSet[1694] = 227(resultSet[1699]) === 155(resultSet[1693]) = false
1	resultSet[1693] = 39;
1	resultSet[1692] = 16;
22	resultSet[1699] = resultSet[1][resultSet[1692](16)]; = 28
		checking equals to 39
8	resultSet[1694] = 28(resultSet[1699]) === 39(resultSet[1693]) = false
1	resultSet[1693] = 242;
1	resultSet[1692] = 17;
22	resultSet[1699] = resultSet[1][resultSet[1692](17)]; = 181
		checking equals to 242
8	resultSet[1694] = 181(resultSet[1699]) === 242(resultSet[1693]) = false
1	resultSet[1693] = 236;
1	resultSet[1692] = 18;
22	resultSet[1699] = resultSet[1][resultSet[1692](18)]; = 186
		checking equals to 236
8	resultSet[1694] = 186(resultSet[1699]) === 236(resultSet[1693]) = false
1	resultSet[1693] = 47;
1	resultSet[1692] = 19;
22	resultSet[1699] = resultSet[1][resultSet[1692](19)]; = 120
		checking equals to 47
8	resultSet[1694] = 120(resultSet[1699]) === 47(resultSet[1693]) = false
1	resultSet[1693] = 13;
1	resultSet[1692] = 20;
22	resultSet[1699] = resultSet[1][resultSet[1692](20)]; = 52
		checking equals to 13
8	resultSet[1694] = 52(resultSet[1699]) === 13(resultSet[1693]) = false
1	resultSet[1698] = 1;
15	returning resultSet[1698](1)