1	resultSet[1686] = -559038737;
1	resultSet[1685] = 0;
6	resultSet[1684] = 1[length] = 1
2	resultSet[1684] += -1; = 0
12	resultSet[1691] = resultSet[1684];
2	resultSet[1691] += 1; = 1
2	resultSet[1686] += -1640531527; = -2199570264
3	resultSet[1686] ^= resultSet[1686](2095400013) >>> 16; = 2095400013
4	resultSet[1686] = Math.imul(resultSet[1686](-1686484471), 569420461); = -1686484471
3	resultSet[1686] ^= resultSet[1686](-1686405891) >>> 15; = -1686405891
4	resultSet[1686] = Math.imul(resultSet[1686](46215739), 1935289751); = 46215739
3	resultSet[1686] ^= resultSet[1686](46217145) >>> 15; = 46217145
12	resultSet[1690] = resultSet[1686];
13	resultSet[1690] %= resultSet[1691]; = 0
5	resultSet[1690] >= 0
14	swapping vals a[0], a[0] where a = resultSet[1](97); b = resultSet[1690](0); c = resultSet[1684](0)
2	resultSet[1686] += -1640531527; = -1594314382
3	resultSet[1686] ^= resultSet[1686](-1594355318) >>> 16; = -1594355318
4	resultSet[1686] = Math.imul(resultSet[1686](-1096188350), 569420461); = -1096188350
3	resultSet[1686] ^= resultSet[1686](-1096285424) >>> 15; = -1096285424
4	resultSet[1686] = Math.imul(resultSet[1686](1094950512), 1935289751); = 1094950512
3	resultSet[1686] ^= resultSet[1686](1094917367) >>> 15; = 1094917367
22	resultSet[1689] = resultSet[1][resultSet[1684](0)]; = 97
12	resultSet[1688] = resultSet[1686];
1	resultSet[1695] = 2;
31	resultSet[1688] >>>= resultSet[1695](2) = 273729341
30	resultSet[1689] ^= resultSet[1688](273729341) = 273729372
29	resultSet[1689] &= 255 = 92
32	resultSet[1][resultSet[1684](0)] = resultSet[1689]92;
2	resultSet[1684] += -1; = -1
7	resultSet[1694] = -1(resultSet[1684]) > 0(resultSet[1685]) = false
11	false(!resultSet[1694])
1	resultSet[1693] = 48;
1	resultSet[1692] = 0;
22	resultSet[1699] = resultSet[1][resultSet[1692](0)]; = 92
		checking equals to 48
8	resultSet[1694] = 92(resultSet[1699]) === 48(resultSet[1693]) = false
1	resultSet[1693] = 32;
1	resultSet[1692] = 1;
22	resultSet[1699] = resultSet[1][resultSet[1692](1)]; = undefined
		checking equals to 32
8	resultSet[1694] = undefined(resultSet[1699]) === 32(resultSet[1693]) = false
1	resultSet[1693] = 83;
1	resultSet[1692] = 2;
22	resultSet[1699] = resultSet[1][resultSet[1692](2)]; = undefined
		checking equals to 83
8	resultSet[1694] = undefined(resultSet[1699]) === 83(resultSet[1693]) = false
1	resultSet[1693] = 245;
1	resultSet[1692] = 3;
22	resultSet[1699] = resultSet[1][resultSet[1692](3)]; = undefined
		checking equals to 245
8	resultSet[1694] = undefined(resultSet[1699]) === 245(resultSet[1693]) = false
1	resultSet[1693] = 235;
1	resultSet[1692] = 4;
22	resultSet[1699] = resultSet[1][resultSet[1692](4)]; = undefined
		checking equals to 235
8	resultSet[1694] = undefined(resultSet[1699]) === 235(resultSet[1693]) = false
1	resultSet[1693] = 124;
1	resultSet[1692] = 5;
22	resultSet[1699] = resultSet[1][resultSet[1692](5)]; = undefined
		checking equals to 124
8	resultSet[1694] = undefined(resultSet[1699]) === 124(resultSet[1693]) = false
1	resultSet[1693] = 151;
1	resultSet[1692] = 6;
22	resultSet[1699] = resultSet[1][resultSet[1692](6)]; = undefined
		checking equals to 151
8	resultSet[1694] = undefined(resultSet[1699]) === 151(resultSet[1693]) = false
1	resultSet[1693] = 6;
1	resultSet[1692] = 7;
22	resultSet[1699] = resultSet[1][resultSet[1692](7)]; = undefined
		checking equals to 6
8	resultSet[1694] = undefined(resultSet[1699]) === 6(resultSet[1693]) = false
1	resultSet[1693] = 39;
1	resultSet[1692] = 8;
22	resultSet[1699] = resultSet[1][resultSet[1692](8)]; = undefined
		checking equals to 39
8	resultSet[1694] = undefined(resultSet[1699]) === 39(resultSet[1693]) = false
1	resultSet[1693] = 92;
1	resultSet[1692] = 9;
22	resultSet[1699] = resultSet[1][resultSet[1692](9)]; = undefined
		checking equals to 92
8	resultSet[1694] = undefined(resultSet[1699]) === 92(resultSet[1693]) = false
1	resultSet[1693] = 222;
1	resultSet[1692] = 10;
22	resultSet[1699] = resultSet[1][resultSet[1692](10)]; = undefined
		checking equals to 222
8	resultSet[1694] = undefined(resultSet[1699]) === 222(resultSet[1693]) = false
1	resultSet[1693] = 143;
1	resultSet[1692] = 11;
22	resultSet[1699] = resultSet[1][resultSet[1692](11)]; = undefined
		checking equals to 143
8	resultSet[1694] = undefined(resultSet[1699]) === 143(resultSet[1693]) = false
1	resultSet[1693] = 240;
1	resultSet[1692] = 12;
22	resultSet[1699] = resultSet[1][resultSet[1692](12)]; = undefined
		checking equals to 240
8	resultSet[1694] = undefined(resultSet[1699]) === 240(resultSet[1693]) = false
1	resultSet[1693] = 123;
1	resultSet[1692] = 13;
22	resultSet[1699] = resultSet[1][resultSet[1692](13)]; = undefined
		checking equals to 123
8	resultSet[1694] = undefined(resultSet[1699]) === 123(resultSet[1693]) = false
1	resultSet[1693] = 151;
1	resultSet[1692] = 14;
22	resultSet[1699] = resultSet[1][resultSet[1692](14)]; = undefined
		checking equals to 151
8	resultSet[1694] = undefined(resultSet[1699]) === 151(resultSet[1693]) = false
1	resultSet[1693] = 155;
1	resultSet[1692] = 15;
22	resultSet[1699] = resultSet[1][resultSet[1692](15)]; = undefined
		checking equals to 155
8	resultSet[1694] = undefined(resultSet[1699]) === 155(resultSet[1693]) = false
1	resultSet[1693] = 39;
1	resultSet[1692] = 16;
22	resultSet[1699] = resultSet[1][resultSet[1692](16)]; = undefined
		checking equals to 39
8	resultSet[1694] = undefined(resultSet[1699]) === 39(resultSet[1693]) = false
1	resultSet[1693] = 242;
1	resultSet[1692] = 17;
22	resultSet[1699] = resultSet[1][resultSet[1692](17)]; = undefined
		checking equals to 242
8	resultSet[1694] = undefined(resultSet[1699]) === 242(resultSet[1693]) = false
1	resultSet[1693] = 236;
1	resultSet[1692] = 18;
22	resultSet[1699] = resultSet[1][resultSet[1692](18)]; = undefined
		checking equals to 236
8	resultSet[1694] = undefined(resultSet[1699]) === 236(resultSet[1693]) = false
1	resultSet[1693] = 47;
1	resultSet[1692] = 19;
22	resultSet[1699] = resultSet[1][resultSet[1692](19)]; = undefined
		checking equals to 47
8	resultSet[1694] = undefined(resultSet[1699]) === 47(resultSet[1693]) = false
1	resultSet[1693] = 13;
1	resultSet[1692] = 20;
22	resultSet[1699] = resultSet[1][resultSet[1692](20)]; = undefined
		checking equals to 13
8	resultSet[1694] = undefined(resultSet[1699]) === 13(resultSet[1693]) = false
1	resultSet[1698] = 1;
15	returning resultSet[1698](1)