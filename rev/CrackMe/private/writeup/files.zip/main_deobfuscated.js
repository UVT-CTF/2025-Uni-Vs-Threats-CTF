function _0xbb2d6f(_0x215109) {
    this.data = new DataView(_0x215109);
    this._0x5b89d5 = this.data.byteLength;
    this.offset = 0;
    this._0x8f3a04 = 23;
  }
  _0xbb2d6f.prototype._0x1d9f80 = function () {
    return this.offset >= this.data.byteLength;
  };
  _0xbb2d6f.prototype._0x4680f0 = function () {
    if (this._0x5b89d5 - this.offset < 1) {
      return;
    }
    let _0x4cc61d = this.data.getUint8(this.offset);
    this.offset++;
    return _0x4cc61d;
  };
  _0xbb2d6f.prototype._0x2ad457 = function () {
    if (this._0x5b89d5 - this.offset < 2) {
      return;
    }
    let _0xbbfa98 = this.data.getUint16(this.offset, false);
    this.offset += 2;
    return _0xbbfa98;
  };
  _0xbb2d6f.prototype._0x3301d6 = function () {
    if (this._0x5b89d5 - this.offset < 4) {
      return;
    }
    let _0x5737fa = this.data.getFloat32(this.offset, false);
    this.offset += 4;
    return _0x5737fa;
  };
  _0xbb2d6f.prototype._0x346914 = function () {
    if (this._0x5b89d5 - this.offset < 2) {
      return;
    }
    let _0x58b726 = this.data.getInt16(this.offset, false);
    this.offset += 2;
    return _0x58b726;
  };
  _0xbb2d6f.prototype._0x570046 = function () {
    if (this._0x5b89d5 - this.offset < 4) {
      return;
    }
    let _0x1cda14 = this.data.getUint32(this.offset, false);
    this.offset += 4;
    return _0x1cda14;
  };
  _0xbb2d6f.prototype._0xbd648e = function () {
    if (this._0x5b89d5 - this.offset < 4) {
      return;
    }
    let _0x2cff64 = this.data.getInt32(this.offset, false);
    this.offset += 4;
    return _0x2cff64;
  };
  _0xbb2d6f.prototype._0x437d43 = function () {
    let _0x4ef4c5 = "";
    let _0x3c1bc3 = this._0x2ad457() ^ 15821;
    let _0x52853d = 0;
    for (let _0x50b92a = 0; _0x50b92a < _0x3c1bc3; _0x50b92a++) {
      let _0xf175fa = this._0x346914() ^ this._0x8f3a04;
      _0x4ef4c5 += String.fromCharCode(_0xf175fa + _0x52853d);
      this._0x8f3a04 ^= 25;
      _0x52853d = _0xf175fa + _0x52853d;
    }
    return _0x4ef4c5;
  };
  _0xbb2d6f.prototype._0x4d8b00 = function (_0x425144) {
    while (this.offset % _0x425144 !== 0) {
      this._0x4680f0();
    }
  };
  function _0x1b831a(_0x427ef2, _0x312b4b = []) {
    let _0x1ee5bf = {};
    let _0x4a9c6c = 0;
    for (let _0x516f33 of _0x312b4b) _0x1ee5bf[++_0x4a9c6c] = _0x516f33;
    let _0x1e99ab = new _0xbb2d6f(_0x427ef2);
    function _0x2a2ec6() {
      let _0x4490a7 = _0x1e99ab._0x4680f0();
      switch (_0x4490a7) {
        case 1:
          return _0x1e99ab._0xbd648e();
        case 2:
          return _0x1e99ab._0x3301d6();
      }
    }
    while (!_0x1e99ab._0x1d9f80()) {
      let _0x314d95 = _0x1e99ab._0x4680f0() ^ 174;
      let _0x236c3b;
      switch (_0x314d95) {
        case 1:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x2a2ec6();
          break;
        case 2:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] += _0x2a2ec6();
          break;
        case 3:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] ^= _0x1ee5bf[_0x236c3b] >>> _0x2a2ec6();
          break;
        case 4:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = Math.imul(_0x1ee5bf[_0x236c3b], _0x2a2ec6());
          break;
        case 5:
          _0x236c3b = _0x1e99ab._0x2ad457();
          if (_0x1ee5bf[_0x236c3b] < 0) {
            _0x1ee5bf[_0x236c3b] = -_0x1ee5bf[_0x236c3b];
          }
          break;
        case 6:
          _0x236c3b = _0x1e99ab._0x2ad457();
          let _0x4a5857 = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          _0x1ee5bf[_0x236c3b] = undefined;
          let _0x42a856 = _0x1e99ab._0x4680f0();
          for (let _0x329a66 = 0; _0x329a66 < _0x42a856; _0x329a66++) {
            let _0x27ddfc = _0x1e99ab._0x437d43();
            _0x1ee5bf[_0x236c3b] = (_0x1ee5bf[_0x236c3b] || _0x4a5857)[_0x27ddfc];
          }
          break;
        case 7:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1ee5bf[_0x1e99ab._0x2ad457()] > _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 8:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1ee5bf[_0x1e99ab._0x2ad457()] === _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 9:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1ee5bf[_0x1e99ab._0x2ad457()] >= _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 10:
          _0x236c3b = _0x1e99ab._0x2ad457();
          if (!_0x1ee5bf[_0x236c3b]) {
            _0x1e99ab.offset = _0x1e99ab._0x570046();
          }
          break;
        case 11:
          _0x236c3b = _0x1e99ab._0x2ad457();
          if (_0x1ee5bf[_0x236c3b]) {
            _0x1e99ab.offset = _0x1e99ab._0x570046();
          }
          break;
        case 12:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 13:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] %= _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 14:
          let _0x30cd99 = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          let _0x2be3ce = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          let _0x54bba5 = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          let _0x57f0fe = _0x30cd99[_0x2be3ce];
          _0x30cd99[_0x2be3ce] = _0x30cd99[_0x54bba5];
          _0x30cd99[_0x54bba5] = _0x57f0fe;
          break;
        case 15:
          return _0x1ee5bf[_0x1e99ab._0x2ad457()];
        case 16:
          let _0x20b32e = _0x1e99ab._0x4680f0();
          let _0x4ccac9 = "";
          for (let _0x2e85c9 = 0; _0x2e85c9 < _0x20b32e; _0x2e85c9++) {
            _0x4ccac9 += _0x1ee5bf[_0x1e99ab._0x2ad457()] + " ";
          }
          console.log(_0x4ccac9);
          break;
        case 18:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] += _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 20:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = [];
          break;
        case 21:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b].push(_0x1ee5bf[_0x1e99ab._0x2ad457()]);
          break;
        case 22:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1ee5bf[_0x1e99ab._0x2ad457()][_0x1ee5bf[_0x1e99ab._0x2ad457()]];
          break;
        case 23:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = !_0x1ee5bf[_0x236c3b];
          break;
        case 24:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] = _0x1e99ab._0x437d43();
          break;
        case 25:
          _0x236c3b = _0x1e99ab._0x2ad457();
          let _0x53ca46 = _0x1e99ab._0x4680f0();
          let _0x5f033c = [];
          for (let _0x21aba9 = 0; _0x21aba9 < _0x53ca46; _0x21aba9++) {
            _0x5f033c.push(_0x1ee5bf[_0x1e99ab._0x2ad457()]);
          }
          _0x1ee5bf[_0x236c3b].apply(null, _0x5f033c);
          break;
        case 26:
          _0x236c3b = _0x1e99ab._0x2ad457();
          let _0x1e3ec2 = _0x1e99ab._0x2ad457();
          let _0x43626b = _0x1e99ab._0x4680f0();
          let _0x3111f5 = [];
          for (let _0x21b932 = 0; _0x21b932 < _0x43626b; _0x21b932++) {
            _0x3111f5.push(_0x1ee5bf[_0x1e99ab._0x2ad457()]);
          }
          _0x1ee5bf[_0x1e3ec2] = _0x1ee5bf[_0x236c3b].apply(null, _0x3111f5);
          break;
        case 27:
          _0x236c3b = _0x1e99ab._0x2ad457();
          let _0x395a89 = _0x1e99ab._0x437d43();
          let _0x458797 = _0x1ee5bf[_0x236c3b];
          let _0x1d511c = _0x1e99ab._0x2ad457();
          let _0x57a22e = _0x1e99ab._0x4680f0();
          let _0x41e955 = [];
          for (let _0x1d760b = 0; _0x1d760b < _0x57a22e; _0x1d760b++) {
            _0x41e955.push(_0x1ee5bf[_0x1e99ab._0x2ad457()]);
          }
          _0x1ee5bf[_0x1d511c] = _0x458797[_0x395a89].apply(_0x458797, _0x41e955);
          break;
        case 28:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b][_0x1e99ab._0x437d43()] = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 29:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] &= _0x2a2ec6();
          break;
        case 30:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] ^= _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 31:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b] >>>= _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        case 32:
          _0x236c3b = _0x1e99ab._0x2ad457();
          _0x1ee5bf[_0x236c3b][_0x1ee5bf[_0x1e99ab._0x2ad457()]] = _0x1ee5bf[_0x1e99ab._0x2ad457()];
          break;
        default:
          throw new Error("invalid: " + _0x314d95 + " " + _0x1e99ab.offset);
      }
      _0x1e99ab._0x4d8b00(8);
    }
  }
  const _0xc02da8 = new Uint8Array([175, 6, 150, 1, 222, 173, 190, 239, 175, 6, 149, 1, 0, 0, 0, 0, 168, 6, 148, 0, 1, 1, 61, 203, 0, 123, 255, 247, 0, 30, 255, 247, 0, 26, 255, 250, 38, 20, 211, 29, 172, 6, 148, 1, 255, 255, 255, 255, 162, 6, 155, 6, 148, 247, 104, 138, 172, 6, 155, 1, 0, 0, 0, 1, 172, 6, 150, 1, 158, 55, 121, 185, 173, 6, 150, 1, 0, 0, 0, 16, 170, 6, 150, 1, 33, 240, 170, 173, 173, 6, 150, 1, 0, 0, 0, 15, 170, 6, 150, 1, 115, 90, 45, 151, 173, 6, 150, 1, 0, 0, 0, 15, 162, 6, 154, 6, 150, 195, 138, 153, 163, 6, 154, 6, 155, 107, 55, 208, 171, 6, 154, 87, 101, 241, 37, 11, 160, 0, 1, 6, 154, 6, 148, 138, 172, 6, 150, 1, 158, 55, 121, 185, 173, 6, 150, 1, 0, 0, 0, 16, 170, 6, 150, 1, 33, 240, 170, 173, 173, 6, 150, 1, 0, 0, 0, 15, 170, 6, 150, 1, 115, 90, 45, 151, 173, 6, 150, 1, 0, 0, 0, 15, 184, 6, 153, 0, 1, 6, 148, 174, 162, 6, 152, 6, 150, 245, 170, 58, 175, 6, 159, 1, 0, 0, 0, 2, 177, 6, 152, 6, 159, 173, 2, 0, 176, 6, 153, 6, 152, 171, 123, 70, 179, 6, 153, 1, 0, 0, 0, 255, 142, 0, 1, 6, 148, 6, 153, 39, 172, 6, 148, 1, 255, 255, 255, 255, 169, 6, 158, 6, 148, 6, 149, 50, 165, 6, 158, 0, 0, 0, 48, 179, 175, 6, 157, 1, 0, 0, 0, 48, 175, 6, 156, 1, 0, 0, 0, 0, 184, 6, 163, 0, 1, 6, 156, 28, 166, 6, 158, 6, 163, 6, 157, 86, 164, 6, 158, 0, 0, 4, 104, 101, 175, 6, 157, 1, 0, 0, 0, 32, 175, 6, 156, 1, 0, 0, 0, 1, 184, 6, 163, 0, 1, 6, 156, 164, 166, 6, 158, 6, 163, 6, 157, 91, 164, 6, 158, 0, 0, 4, 104, 154, 175, 6, 157, 1, 0, 0, 0, 83, 175, 6, 156, 1, 0, 0, 0, 2, 184, 6, 163, 0, 1, 6, 156, 55, 166, 6, 158, 6, 163, 6, 157, 81, 164, 6, 158, 0, 0, 4, 104, 208, 175, 6, 157, 1, 0, 0, 0, 245, 175, 6, 156, 1, 0, 0, 0, 3, 184, 6, 163, 0, 1, 6, 156, 209, 166, 6, 158, 6, 163, 6, 157, 132, 164, 6, 158, 0, 0, 4, 104, 59, 175, 6, 157, 1, 0, 0, 0, 235, 175, 6, 156, 1, 0, 0, 0, 4, 184, 6, 163, 0, 1, 6, 156, 103, 166, 6, 158, 6, 163, 6, 157, 91, 164, 6, 158, 0, 0, 4, 104, 245, 175, 6, 157, 1, 0, 0, 0, 124, 175, 6, 156, 1, 0, 0, 0, 5, 184, 6, 163, 0, 1, 6, 156, 56, 166, 6, 158, 6, 163, 6, 157, 162, 164, 6, 158, 0, 0, 4, 104, 229, 175, 6, 157, 1, 0, 0, 0, 151, 175, 6, 156, 1, 0, 0, 0, 6, 184, 6, 163, 0, 1, 6, 156, 109, 166, 6, 158, 6, 163, 6, 157, 225, 164, 6, 158, 0, 0, 4, 104, 202, 175, 6, 157, 1, 0, 0, 0, 6, 175, 6, 156, 1, 0, 0, 0, 7, 184, 6, 163, 0, 1, 6, 156, 1, 166, 6, 158, 6, 163, 6, 157, 132, 164, 6, 158, 0, 0, 4, 104, 175, 175, 6, 157, 1, 0, 0, 0, 39, 175, 6, 156, 1, 0, 0, 0, 8, 184, 6, 163, 0, 1, 6, 156, 142, 166, 6, 158, 6, 163, 6, 157, 156, 164, 6, 158, 0, 0, 4, 104, 91, 175, 6, 157, 1, 0, 0, 0, 92, 175, 6, 156, 1, 0, 0, 0, 9, 184, 6, 163, 0, 1, 6, 156, 8, 166, 6, 158, 6, 163, 6, 157, 203, 164, 6, 158, 0, 0, 4, 104, 216, 175, 6, 157, 1, 0, 0, 0, 222, 175, 6, 156, 1, 0, 0, 0, 10, 184, 6, 163, 0, 1, 6, 156, 112, 166, 6, 158, 6, 163, 6, 157, 131, 164, 6, 158, 0, 0, 4, 104, 77, 175, 6, 157, 1, 0, 0, 0, 143, 175, 6, 156, 1, 0, 0, 0, 11, 184, 6, 163, 0, 1, 6, 156, 83, 166, 6, 158, 6, 163, 6, 157, 231, 164, 6, 158, 0, 0, 4, 104, 222, 175, 6, 157, 1, 0, 0, 0, 240, 175, 6, 156, 1, 0, 0, 0, 12, 184, 6, 163, 0, 1, 6, 156, 120, 166, 6, 158, 6, 163, 6, 157, 189, 164, 6, 158, 0, 0, 4, 104, 172, 175, 6, 157, 1, 0, 0, 0, 123, 175, 6, 156, 1, 0, 0, 0, 13, 184, 6, 163, 0, 1, 6, 156, 19, 166, 6, 158, 6, 163, 6, 157, 176, 164, 6, 158, 0, 0, 4, 104, 22, 175, 6, 157, 1, 0, 0, 0, 151, 175, 6, 156, 1, 0, 0, 0, 14, 184, 6, 163, 0, 1, 6, 156, 103, 166, 6, 158, 6, 163, 6, 157, 2, 164, 6, 158, 0, 0, 4, 104, 217, 175, 6, 157, 1, 0, 0, 0, 155, 175, 6, 156, 1, 0, 0, 0, 15, 184, 6, 163, 0, 1, 6, 156, 240, 166, 6, 158, 6, 163, 6, 157, 175, 164, 6, 158, 0, 0, 4, 104, 218, 175, 6, 157, 1, 0, 0, 0, 39, 175, 6, 156, 1, 0, 0, 0, 16, 184, 6, 163, 0, 1, 6, 156, 168, 166, 6, 158, 6, 163, 6, 157, 196, 164, 6, 158, 0, 0, 4, 104, 167, 175, 6, 157, 1, 0, 0, 0, 242, 175, 6, 156, 1, 0, 0, 0, 17, 184, 6, 163, 0, 1, 6, 156, 99, 166, 6, 158, 6, 163, 6, 157, 42, 164, 6, 158, 0, 0, 4, 104, 142, 175, 6, 157, 1, 0, 0, 0, 236, 175, 6, 156, 1, 0, 0, 0, 18, 184, 6, 163, 0, 1, 6, 156, 203, 166, 6, 158, 6, 163, 6, 157, 52, 164, 6, 158, 0, 0, 4, 104, 103, 175, 6, 157, 1, 0, 0, 0, 47, 175, 6, 156, 1, 0, 0, 0, 19, 184, 6, 163, 0, 1, 6, 156, 254, 166, 6, 158, 6, 163, 6, 157, 101, 164, 6, 158, 0, 0, 4, 104, 68, 175, 6, 157, 1, 0, 0, 0, 13, 175, 6, 156, 1, 0, 0, 0, 20, 184, 6, 163, 0, 1, 6, 156, 239, 166, 6, 158, 6, 163, 6, 157, 183, 164, 6, 158, 0, 0, 4, 104, 178, 175, 6, 162, 1, 0, 0, 0, 1, 161, 6, 162, 52, 197, 32, 167, 25, 175, 6, 162, 1, 0, 0, 0, 0, 161, 6, 162, 88, 239, 254, 76, 230]).buffer;
  function _0x146ef1(_0x888926) {
    let _0x21abdb = _0x888926.split("").map(_0x134cb8 => _0x134cb8.charCodeAt(0));
    let _0x50ad94 = _0x1b831a(_0xc02da8, [_0x21abdb]);
    return _0x50ad94 === 1;
  }
  let _0x7cd726 = document.getElementById("result");
  let _0x46c1f3 = document.getElementById("pw");
  let _0x5e11d7 = document.getElementById("submit");
  _0x5e11d7.onclick = function () {
    _0x7cd726.classList.add("visible");
    if (_0x46c1f3.value && _0x146ef1(_0x46c1f3.value)) {
      _0x7cd726.innerText = "Correct!";
    } else {
      _0x7cd726.innerText = "Incorrect!";
    }
  };