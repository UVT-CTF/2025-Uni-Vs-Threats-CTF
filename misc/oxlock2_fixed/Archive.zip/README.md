### 0xL0cK

> author: AndraB, category: Misc

### Description
The terminal's screen is alive still—unnaturally so. No flicker, no static, just a cold, unblinking glow. The keys press too softly, like the machine is holding its breath. It's waiting. You'll have to outsmart it, feed it the right lies, make it believe you're just another error in its system.

One wrong move, and it wakes up.

### Flag 
<details>
  <summary>Click to reveal the flag</summary>
  UVT{Th3_m3ch4n1sM_UNs3a15_4nd_tH3_DaRK_uNBl1nk5}
</details>